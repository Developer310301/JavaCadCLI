/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javacad;

import shaders.*;

/**
 * Classe che istanzia oggetti per determinare un disegno
 * @author Barbato Federico
 */
public class Sketch implements java.io.Serializable {
    private final int nMax=10;
    Point[] arrayPoint;
    Point3d[] arrayPoint3d;
    Segment[] arraySegment;
    Segment3d[] arraySegment3d;
    Circle[] arrayCircle;
    Sphere[] arraySphere;
    
    /**
     * Costruttuore usato per istanziare un nuovo disegno
     */
    public Sketch(){
        arrayPoint=new Point[nMax];
        arrayPoint3d=new Point3d[nMax];
        arraySegment=new Segment[nMax];
        arraySegment3d=new Segment3d[nMax];
        arrayCircle=new Circle[nMax];
        arraySphere=new Sphere[nMax];
    }
    
    /**
     * Metodo che, passando per la lista dei parametri un oggetto di tipo Point, aggiunge all'array di punti il punto istanziato
     * @param p Punto
     */
    public void addPoint(Point p){
        for(int i=0;i<nMax;i++){
            if(arrayPoint[i]==null){
                arrayPoint[i]=p;
                break;
            }
        }
    }
    
    /**
     * Metodo che, passando per la lista dei parametri un oggetto di tipo Point3d, aggiunge all'array di punti 3D il punto istanziato
     * @param p Punto 3D
     */
    public void addPoint3d(Point3d p){
        for(int i=0;i<nMax;i++){
            if(arrayPoint3d[i]==null){
                arrayPoint3d[i]=p;
                break;
            }
        }
    }
    
    /**
     * Metodo che, passando per la lista dei parametri un oggetto di tipo Segment, aggiunge all'array di segmenti il segmento istanziato
     * @param s Segmento
     */
    public void addSegment(Segment s){
        for(int i=0;i<nMax;i++){
            if(arraySegment[i]==null){
                arraySegment[i]=s;
                break;
            }
        }
    }
    
    /**
     * Metodo che, passando per la lista dei parametri un oggetto di tipo Segment3d, aggiunge all'array di segmenti 3D il segmento istanziato
     * @param s Segmento 3D
     */
    public void addSegment3d(Segment3d s){
        for(int i=0;i<nMax;i++){
            if(arraySegment3d[i]==null){
                arraySegment3d[i]=s;
                break;
            }
        }
    }
    
    /**
     * Metodo che, passando per la lista dei parametri un oggetto di tipo Circle, aggiunge all'array di cerchi il cerchio istanziato
     * @param c Cerchio
     */
    public void addCircle(Circle c){
        for(int i=0;i<nMax;i++){
            if(arrayCircle[i]==null){
                arrayCircle[i]=c;
                break;
            }
        }
    }
    
    /**
     * Metodo che, passando per la lista dei parametri un oggetto di tipo Sphere, aggiunge all'array di sfere la sfera istanziato
     * @param s Sfera
     */
    public void addSphere(Sphere s){
        for(int i=0;i<nMax;i++){
            if(arraySphere[i]==null){
                arraySphere[i]=s;
                break;
            }
        }
    }
    
    /**
     * Metodo che, avente in ingresso un numero intero compreso nell'intervallo da 1 a nMax, usa tale valore per rimuovere un punto dall'array di punti
     * @param i Posizione dell'oggetto da rimuovere
     */
    public void removePoint(int i){
        try{
            arrayPoint[i-1]=null;
        }catch(Exception e){
            System.out.println("Inserisci una posizione corretta da 1 a "+nMax);
            
        }
    }
    
    /**
     * Metodo che, avente in ingresso un numero intero compreso nell'intervallo da 1 a nMax, usa tale valore per rimuovere un punto 3D dall'array di punti 3D
     * @param i Posizione dell'oggetto da rimuovere
     */
    public void removePoint3d(int i){
        try{
            arrayPoint3d[i-1]=null;
        }catch(Exception e){
            System.out.println("Inserisci una posizione corretta da 1 a "+nMax);
            
        }
    }
    
    /**
     * Metodo che, avente in ingresso un numero intero compreso nell'intervallo da 1 a nMax, usa tale valore per rimuovere un segmento dall'array di segmenti
     * @param i Posizione dell'oggetto da rimuovere
     */
    public void removeSegment(int i){
        try{
            arraySegment[i-1]=null;
        }catch(Exception e){
            System.out.println("Inserisci una posizione corretta da 1 a "+nMax);
            
        }
    }
    
    /**
     * Metodo che, avente in ingresso un numero intero compreso nell'intervallo da 1 a nMax, usa tale valore per rimuovere un segmento 3D dall'array di segmenti 3D
     * @param i Posizione dell'oggetto da rimuovere
     */
    public void removeSegment3d(int i){
        try{
            arraySegment3d[i-1]=null;
        }catch(Exception e){
            System.out.println("Inserisci una posizione corretta da 1 a "+nMax);
            
        }
    }
    
    /**
     * Metodo che, avente in ingresso un numero intero compreso nell'intervallo da 1 a nMax, usa tale valore per rimuovere un cerchio dall'array di cerchi
     * @param i Posizione dell'oggetto da rimuovere
     */
    public void removeCircle(int i){
        try{
            arrayCircle[i-1]=null;
        }catch(Exception e){
            System.out.println("Inserisci una posizione corretta da 1 a "+nMax);
            
        }
    }
    
    /**
     * Metodo che, avente in ingresso un numero intero compreso nell'intervallo da 1 a nMax, usa tale valore per rimuovere una sfera dall'array di sfere
     * @param i Posizione dell'oggetto da rimuovere
     */
    public void removeSphere(int i){
        try{
            arraySphere[i-1]=null;
        }catch(Exception e){
            System.out.println("Inserisci una posizione corretta da 1 a "+nMax);
            
        }
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutti i punti presenti nel loro array
     * @return Stringa
     */
    public String PointToString(){
        String s="-> PUNTI:\n";
        
        for(int i=0;i<nMax;i++){
            if(arrayPoint[i]!=null)
                s+="\t - Pos."+i+": p"+arrayPoint[i].toString()+"\n";
        }
        
        return s+="\n";
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutti i punti 3D presenti nel loro array
     * @return Stringa
     */
    public String Point3dToString(){
        String s="-> PUNTI 3D:\n";
        
        for(int i=0;i<nMax;i++){
            if(arrayPoint3d[i]!=null)
                s+="\t - Pos."+i+": p"+arrayPoint[i].toString()+"\n";
        }
        
        return s+="\n";
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutti i segmenti presenti nel loro array
     * @return Stringa
     */
    public String SegmentToString(){
        String s="-> SEGMENTI:\n";
        
        for(int i=0;i<nMax;i++){
            if(arraySegment[i]!=null)
                s+="\t - Pos."+i+": "+arraySegment[i].toString()+"\n";
        }
        
        return s+="\n";
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutti i segmenti 3D presenti nel loro array
     * @return Stringa
     */
    public String Segment3dToString(){
        String s="-> SEGMENTI 3D:\n";
        
        for(int i=0;i<nMax;i++){
            if(arraySegment3d[i]!=null)
                s+="\t - Pos."+i+": "+arraySegment3d[i].toString()+"\n";
        }
        
        return s+="\n";
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutti i cerchi presenti nel loro array
     * @return Stringa
     */
    public String CircleToString(){
        String s="-> CERCHI:\n";
        
        for(int i=0;i<nMax;i++){
            if(arrayCircle[i]!=null)
                s+="\t - Pos."+i+": "+arrayCircle[i].toString()+"\n";
        }
        
        return s+="\n";
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutte le sfere presenti nel loro array
     * @return Stringa
     */
    public String SphereToString(){
        String s="-> SFERE:\nunserialize"
                + "";
        
        for(int i=0;i<nMax;i++){
            if(arraySphere[i]!=null)
                s+="\t - Pos."+i+": "+arraySphere[i].toString()+"\n";
        }
        
        return s+="\n";
    }
    
    /**
     * Metodo che restituisce una stringa con le caratteristiche di tutti gli elementi dello sketch
     * @return Stringa
     */
    @Override
    public String toString(){
        return this.PointToString()+this.Point3dToString()+this.SegmentToString()+this.Segment3dToString()+this.CircleToString()+this.SphereToString();
    }
    
}
