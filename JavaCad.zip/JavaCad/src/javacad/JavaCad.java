/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javacad;

import java.io.*;
import java.util.Scanner;
import shaders.*;

/**
 *
 * @author virtual
 */
public class JavaCad {

    private static Scanner input=new Scanner(System.in);
    private static Sketch disegno=new Sketch();
    
    private enum Shape{
        punto,
        punto3d,
        segmento,
        segmento3d,
        cerchio,
        sfera,
        help,
        exit
    }
    private enum Home{
        add,
        remove,
        serialize,
        unserialize,
        viewdraw,
        help,
        exit
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        menuHome();
    }
    
    /**
     * Metodo che permette la selezione tra l'aggiunta o la rimozione di oggetti e la selezione tra salvare o caricare il disegno corrente
     */
    public static void menuHome(){
        Home s;
        do{
            System.out.print("\t\tJAVACAD - HOME\nhome> ");
            s=Home.valueOf(input.next());
            switch(s){
                case add:
                    menuInsert();
                    break;
                case remove:
                    menuRemove();
                    break;
                case serialize:
                    try{
                        saveSketch();
                    }catch(java.io.IOException e){
                        System.out.println("Errore nel Salvataggio del Disegno!");
                    }
                    
                    break;
                case unserialize:
                    try{
                        loadSketch();
                    }catch(java.io.IOException e){
                        System.out.println("Errore nell'apertura del Disegno!\n"+e.toString());
                    }
                    break;
                case viewdraw:
                    viewSketch();
                    break;
                case help:
                    viewHelp();
                    break;
            }
        }while(s!=Home.exit);
        
    }
    
    /**
     * Metodo che permette l'aggiunta di elementi al disegno
     */
    public static void menuInsert(){
        Shape s;
        
        do{
           System.out.print("\t\tJAVACAD - INSERT\ninsert> ");
           s=Shape.valueOf(input.next());
            switch(s){
                case punto:
                    addPoint();
                    break;
                case punto3d:
                    addPoint3d();
                    break;
                case segmento:
                    addSegment();
                    break;
                case segmento3d:
                    addSegment3d();
                    break;
                case cerchio:
                    addCircle();
                    break;
                case sfera:
                    addSphere();
                    break;
                case help:
                    viewHelpShape();
                    break;
            } 
        }while(s!=Shape.exit);
        
    }
    
    /**
     * Metodo che permette la rimozione di oggetti dal disegno corrente
     */
    public static void menuRemove(){
       
       
       Shape s;
        do{
           System.out.print("\t\tJAVACAD - DELETE\ndelete> ");
           s=Shape.valueOf(input.next());
            switch(s){
                case punto:
                    removePoint();
                    break;
                case punto3d:
                    removePoint3d();
                    break;
                case segmento:
                    removeSegment();
                    break;
                case segmento3d:
                    removeSegment3d();
                    break;
                case cerchio:
                    removeCircle();
                    break;
                case sfera:
                    removeSphere();
                    break;
                case help:
                    viewHelpShape();
                    break;
            } 
        }while(s!=Shape.exit);
    }
    
    /**
     * Metodo che permette l'aggiunta di un punto al disegno
     */
    public static void addPoint(){
        
        String c;
        String[] coord;
        
        System.out.print("addPoint> Inserisci le coordinate del punto (x;y):");
        
        c=input.next();
        coord=c.split(";");
        
        Point p = new Point(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]));
        
        disegno.addPoint(p);
        
    }
    
    /**
     * Metodo che permette l'aggiunta di un punto 3D al disegno
     */
    public static void addPoint3d(){
        
        String c;
        String[] coord;
        
        System.out.print("addPoint3d> Inserisci le coordinate del punto (x;y;z):");
        
        c=input.next();
        coord=c.split(";");
        
        Point3d p = new Point3d(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]),Double.parseDouble(coord[2]));
        
       disegno.addPoint3d(p);
        
    }
    
    /**
     * Metodo che permette l'aggiunta di un segmento al disegno
     */
    public static void addSegment(){
        
        String c;
        String[] coord;
        
        System.out.print("addSegment> Inserisci le coordinate del punto primo (x;y):");
        
        c=input.next();
        coord=c.split(";");
        
        Point p1 = new Point(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]));
        
        System.out.print("addSegment> Inserisci le coordinate del punto primo (x;y):");
        
        c=input.next();
        coord=c.split(";");
        
        Point p2 = new Point(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]));
        
        Segment seg=new Segment(p1,p2);
        
        disegno.addSegment(seg);
        
    }
    
    /**
     * Metodo che permette l'aggiunta di un segmento 3D al disegno
     */
    public static void addSegment3d(){
        
        String c;
        String[] coord;
        
        System.out.print("addSegment3d> Inserisci le coordinate del punto primo (x;y;z):");
        
        c=input.next();
        coord=c.split(";");
        
        Point3d p1 = new Point3d(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]),Double.parseDouble(coord[2]));
        
        System.out.print("addSegment3d> Inserisci le coordinate del punto primo (x;y;z):");
        
        c=input.next();
        coord=c.split(";");
        
        Point3d p2 = new Point3d(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]),Double.parseDouble(coord[2]));
        
        Segment3d seg=new Segment3d(p1,p2);
        
        disegno.addSegment3d(seg);
        
    }
    
    /**
     * Metodo che permette l'aggiunta di un cerchio al disegno
     */
    public static void addCircle(){
        String c;
        String[] coord;
        double l;
        
        System.out.print("addCircle> Inserisci le coordinate del centro del cerchio (x;y):");
        
        c=input.next();
        coord=c.split(";");
        
        Point p = new Point(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]));
        
        System.out.print("addCircle> Inserisci la lunghezza del raggio:");
        l=input.nextDouble();
        
        Circle cir=new Circle(p,l);
        
        disegno.addCircle(cir);
    }
    
    /**
     * Metodo che permette l'aggiunta di una sfera al disegno
     */
    public static void addSphere(){
        String c;
        String[] coord;
        double l;
        
        System.out.print("addSphere> Inserisci le coordinate del centro del cerchio (x;y;z):");
        
        c=input.next();
        coord=c.split(";");
        
        Point3d p = new Point3d(Double.parseDouble(coord[0]),Double.parseDouble(coord[1]),Double.parseDouble(coord[2]));
        
        System.out.print("addSphere> Inserisci la lunghezza del raggio:");
        l=input.nextDouble();
        
        Sphere sp=new Sphere(p,l);
        
        disegno.addSphere(sp);
    }
    
    /**
     * Metodo che permette la rimozione di un punto dal disegno
     */
    public static void removePoint(){
        
        System.out.print("removePoint> Scegli il punto da eliminare: ");
        disegno.removePoint(input.nextInt());
    }
    
    /**
     * Metodo che permette la rimozione di un punto 3D dal disegno
     */
    public static void removePoint3d(){
        
        System.out.print("removePoint3d> Scegli il punto da eliminare: ");
        disegno.removePoint3d(input.nextInt());
    }
    
    /**
     * Metodo che permette la rimozione di un segmento dal disegno
     */
    public static void removeSegment(){
        
        System.out.print("removeSegment> Scegli il segmento da eliminare: ");
        disegno.removeSegment(input.nextInt());
    }
    
    /**
     * Metodo che permette la rimozione di un segmento 3D dal disegno
     */
    public static void removeSegment3d(){
        
        System.out.print("removeSegment3d> Scegli il segmento da eliminare: ");
        disegno.removeSegment3d(input.nextInt());
    }
    
    /**
     * Metodo che permette la rimozione di un cerchio dal disegno
     */
    public static void removeCircle(){
        
        System.out.print("removeCircle> Scegli il cerchio da eliminare: ");
        disegno.removeCircle(input.nextInt());
    }
    
    /**
     * Metodo che permette la rimozione di una sfera dal disegno
     */
    public static void removeSphere(){
        
        System.out.print("removeSphere> Scegli la sfera da eliminare: ");
        disegno.removeSphere(input.nextInt());
    }
    
    /**
     * Metodo che permette la visualizza degli elementi componenti del disegno
     */
    public static void viewSketch(){
        System.out.println(disegno.toString());
    }
    
    /**
     * Metodo che permette il salvataggio su file del disegno disegno
     * @throws java.io.IOException Eccezione sollevata in caso di input non corretto
     */
    public static void saveSketch() throws java.io.IOException{
        try (ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("sketch.bin"))) {
            stream.writeObject(disegno);
        }
    }
    
    /**
     * Metodo che permette il caricamento di un disegno
     * @throws java.io.IOException Eccezione sollevata in caso di input non corretto
     */
    public static void loadSketch()throws java.io.IOException{
        ObjectInputStream stream= new ObjectInputStream(new FileInputStream("sketch.bin"));
        try{
            disegno=(Sketch)stream.readObject();
        }catch(ClassNotFoundException e){
            
        }
        stream.close();
    }
    
    /**
     * Metodo che permette la visualizzazione dei comandi disponibili nel menu home
     */
    public static void viewHelp(){
        System.out.println("Comandi della pagina home");
        for( Home h : Home.values()  ) {
            System.out.println("\t-"+h);
        }
    }
    
    /**
     * Metodo che permette la visualizzazione dei comandi disponibili nel menu di aggiunta e rimozione degli oggetti
     */
    public static void viewHelpShape(){
        System.out.println("Comandi della pagina Shape");
        for( Shape s : Shape.values()  ) {
            System.out.println("\t-"+s);
        }
    }
}
