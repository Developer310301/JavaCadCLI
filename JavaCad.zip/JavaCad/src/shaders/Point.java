/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shaders;

/**
 *	Classe utilizzata per definire attributi e metodi di un punto in un piano bidimensionale.
 *	
 *	@author Barbato Federico
 *	
 *	@version 1.0.0
 */
 
import graphics.MasterGraphic;
import java.awt.Color;
 
public class Point extends MasterGraphic implements java.io.Serializable{
    private double x;
    private double y;
	
	/**
	* Costruttore che alloca in memoria un oggetto di tipo Point inserendo in ingresso l'ordinata e l'ascissa del punto senza caratteristiche grafiche
	* 
	* @param x Ascissa del punto
	* @param y Ordinata del punto
	*/
	public Point(double x, double y){
        super(0,Color.black,true);
		this.x=x;
        this.y=y;
    }
	
	/**
	* Costruttore che alloca in memoria un oggetto di tipo Point inserendo in ingresso l'ordinata e l'ascissa del punto con caratteristiche grafiche
	* 
	* @param x Ascissa del punto
	* @param y Ordinata del punto
	* @param l Spessore della linea
	* @param c Colore della linea
	* @param v Visibilità dell'oggetto
	*/
	public Point(double l, Color c, boolean v, double x, double y){
        super(l,c,v);
		this.x=x;
        this.y=y;
    }
	
    
	/**
	* Metodo che setta l'ascissa del punto
	* 
	* @param x Ascissa del punto
	* 
	*/
    public void setX(double x){
		this.x=x;
	}
	
	/**
	* Metodo che setta l'ordinata del punto
	* 
	* @param y Ordinata del punto
	* 
	*/
	public void setY(double y){  //point p1
		this.y=y;
	}
	
	/**
	* Metodo che restituisce come dato double l'ascissa del punto
	* 
	* @return this.x Valore dell'ascissa del punto
	* 
	*/
	public double getX(){
		return this.x;
	}
	
	/**
	* Metodo che restituisce come dato double l'ordinata del punto
	* 
	* @return this.y Valore dell'ordinata del punto
	* 
	*/
	public double getY(){
		return this.y;
	}
	
	/**
	* Metodo che restituisce come dato double la distanza tra due punti
	* 
	* @param p2 Secondo punto nel piano
	* @return distanza Distanza tra due punti nel piano
	* 
	*/
	public double distance(Point p2){
		double distanza=Math.sqrt((this.x-p2.x)*(this.x-p2.x)+(this.y-p2.y)*(this.y-p2.y));
		return distanza;
	}
	
	/**
	* 
	* Metodo che determina se un punto appartiene a un segmento
	* @param s Segmento da confrontare
	* @return true/false Il punto se appartiene o no al segmento
	*
	*/
	public boolean puntoAppartiene(Segment s){
		if(s instanceof Segment){
			if(s.getP1().distance(this)+s.getP2().distance(this)==s.length())
				return true;
			else
				return false;	
		}else{
			return false;
		}
		
	}
	
	/**
	* Metodo che restituisce se due punti hanno le stesse coordinate
	*
	* @param p2 secondo punto
	* @return true/false se due punti sono uguali
	*/
	public boolean equals(Object p2){
		Point p;
		if(p2 instanceof Point){
			p=(Point)p2;
			if(this.x == p.x && this.y == p.y)
				return true;
			else
				return false;
		}else{
			return false;
		}
		
	}
	
	/**
	* Metodo che restituisce le caratteristiche del punto
	*
	* @return String
	*
	*/
	public String toString(){
		return "("+this.x+";"+this.y+")";
	}
}