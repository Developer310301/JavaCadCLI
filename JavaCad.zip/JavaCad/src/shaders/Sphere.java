/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shaders;

/**
* Classe che serve ad istanziare oggetti di tipo sfera
* 
* @author Barbato Federico
* @version 1.0.0
*/

import graphics.MasterGraphic;
import java.awt.Color;

public class Sphere extends MasterGraphic implements java.io.Serializable{
	//Attributi
	private Point3d centro;//Centro della sfera
	private double raggio;//Raggio della sfera
	
	/**
	*
	* Metodo che instanzia un oggetto di tipo sfera senza attributi grafici
	* @param c Centro della sfera
	* @param r Raggio della sfera
	*
	*/
	public Sphere(Point3d c, double r){
		super(0,Color.black,true);
		this.centro=c;
		this.raggio=r;
	}
	
	/**
	*
	* Metodo che instanzia un oggetto di tipo sfera con attributi grafici
	* @param c Centro della sfera
	* @param r Raggio della sfera
	* @param l Spessore della linea
	* @param cl Colore della linea
	* @param v Visibilità dell'oggettos
	*
	*/
	public Sphere(Point3d c, double r, double l, Color cl, boolean v){
		super(l,cl,v);
		this.centro=c;
		this.raggio=r;
	}
	
	/**
	*
	* Metodo che modifica il centro della sfera
	* 
	* @param c Centro della sfera
	*
	*/
	public void setCentro(Point3d c){
		this.centro=c;
	}
	
	/**
	*
	* Metodo che modifica il raggio della sfera
	*
	* @param r Raggio della sfera
	*
	*/
	public void setRaggio(double r){
		this.raggio=r;
	}
	
	/**
	*
	* Metodo che restituisce il punto del centro del cerchio
	*
	* @return centro Centro del cerchio
	*
	*/
	public Point getCentro(){
		return this.centro;
	}
	
	/**
	*
	* Metodo che restituisce la lunghezza del raggio
	*
	* @return raggio Raggio del cerchio
	*
	*/
	public double getRaggio(){
		return this.raggio;
	}
	
	/**
	*
	* Metodo definisce se un punto appartiene al cerchio
	*
	* @param p Punto da esaminare
	* @return true Punto appartenente al cerchio
	* @return false Punto non appartenente al cerchio
	*
	*/
	public boolean contienePunto(Point3d p){
		Segment3d s=new Segment3d(p,centro);
		double l=s.length();
		if(l <= this.raggio)
			return true;
		else
			return false;
	}
	
	/**
	*
	* Metodo che definisce l'area della superficie della sfera
	* 
	* @return area
	*
	*/
	public double superficie(){
		return Math.PI*4*this.raggio*this.raggio;
	}
	
	
	/**
	*
	* Metodo che definisce il volume della sfera
	* 
	* @return volume
	*
	*/
	public double volume(){
		return this.raggio*this.raggio*this.raggio*Math.PI*4/3;
	}
	
	/**
	*
	* Metodo che restituisce le caratteristiche dela sfera
	*
	* @return string Caratteristiche della sfera
	*
	*/
	public String toString(){
		return "Figura: Sfera\n\t->Coordinate della sfera: "+this.centro.toString()+"\n\t->Lunghezza del raggio: "+this.raggio+"\n\t->Superficie: "+superficie()+"\n\t->Volume: "+volume();
	}
}
