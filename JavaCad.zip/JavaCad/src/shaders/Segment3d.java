/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shaders;

/**
*
* Classe utilizzata per istanziare un oggetto di tipo segmento nelle tre dimensioni
* @author Barbato Federico
* @version 1.0.0
*
*/

import graphics.MasterGraphic;
import java.awt.Color;

public class Segment3d extends MasterGraphic implements java.io.Serializable{
	//Attributi
	private Point3d p1;//Primo Punto 3d
	private Point3d p2;//Secondo Punto 3d
	
	/**
	*
	* Costruttore che serve ad istanziare un segmento 3d senza attributi grafici
	* @param p1 Primo punto 3d
	* @param p2 Secondo Punto 3d
	*
	*/
	public Segment3d(Point3d p1, Point3d p2){
		super(0,Color.black,true);
		this.p1=p1;
		this.p2=p2;
	}
	
	/**
	*
	* Costruttore che serve ad istanziare un segmento 3d con attributi grafici
	* @param p1 Primo punto 3d
	* @param p2 Secondo Punto 3d
	* @param l Spessore della linea
	* @param c Colore della linea
	* @param v Visibilità dell'oggetto
	*
	*/
	public Segment3d(Point3d p1, Point3d p2, double l, Color c, boolean v){
		super(l,c,v);
		this.p1=p1;
		this.p2=p2;
	}
	
	/**
	*
	* Metodo che serve a modificare il primo punto
	* @param p Punto 3d
	*
	*/
	public void setP1(Point3d p){
		this.p1=p;
	}
	
	/**
	*
	* Metodo che serve a modificare il secondo punto
	* @param p Punto 3d
	*
	*/
	public void setP2(Point3d p){
		this.p2=p;
	}
	
	/**
	*
	* Metodo che serve ad ottenere il primo punto
	* @return p1 Punto 3d
	*
	*/
	public Point3d getP1(){
		return this.p1;
	}
	
	/**
	*
	* Metodo che serve ad ottenere il secondo punto
	* @return p1 Punto 3d
	*
	*/
	public Point3d getP2(){
		return this.p2;
	}
	
	/**
	*
	* Metodo che serve ad ottenere la lunhezza del segmento
	* @return s Lunghezza del segmento
	*
	*/
	public double length(){
		double lunghezza=p1.distance(p2);
		return lunghezza;
	}
	
	/**
	*
	* Metodo che serve ad ottenere sottoforma di stringa le caratteristiche del segmento
	* @return s Caratteristiche del segmento
	*
	*/
	public String toString(){
		return "\n\t-->punto A"+ p1.toString()+"\n\t-->punto B"+ p2.toString() +"\n\t--> Lunghezza: "+length();
	}
	
	/**
	* Metodo che serve a determinare se due segmenti 3d sono uguali
	* @param s2 Segmento 3d
	* @return true segmenti uguali
	* @return false segmenti diversi
	*/
	public boolean equals(Object s2){
		Segment3d s;
		if(s2 instanceof Segment){
			s=(Segment3d)s2;
			if(this.p1.equals(s.getP1()) && this.p2.equals(s.getP2()))
				return true;
			else
				return false;
		}else{
			return false;
		}
		
	}
}
