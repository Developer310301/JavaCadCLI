/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shaders;

/**
* Classe che determina un oggetti di tipo Circle
*
*	@author Barbato Federico
*	@version 1.0.0
*
*/

import graphics.MasterGraphic;
import java.awt.Color;

public class Circle extends MasterGraphic implements java.io.Serializable{
	private Point centro;
	private double raggio;
	
	/**
	* Costruttore di classe Circle che determina il centro e il raggio del cerchio senza attributi grafici
	*
	* @param c Centro
	* @param r Raggio
	*
	*/
	public Circle(Point c, double r){
		super(0,Color.black,true);
		this.centro=c;
		this.raggio=r;
	}
	
	/**
	* Costruttore di classe Circle che determina il centro e il raggio del cerchio con attributi grafici
	*
	* @param c Centro
	* @param r Raggio
	* @param l Spessore della linea
	* @param cl Colore della linea
	* @param v Visibilità dell'oggetto
	*
	*/
	public Circle(Point c, double r,double l, Color cl, boolean v){
		super(l,cl,v);
		this.centro=c;
		this.raggio=r;
	}
	
	/**
	*
	* Metodo che restituisce il punto del centro del cerchio
	*
	* @return this.centro Centro del cerchio
	*
	*/
	public Point getCentro(){
		return this.centro;
	}
	
	/**
	*
	* Metodo che setta il punto del centro del cerchio
	*
	* @param c Centro del cerchio
	*
	*/
	public void setCentro(Point c){
		this.centro=c;
	}
	
	/**
	*
	* Metodo che restituisce la lunghezza del raggio
	*
	* @return this.raggio Raggio del cerchio
	*
	*/
	public double getRaggio(){
		return this.raggio;
	}
	
	/**
	*
	* Metodo che setta il valore del raggio del cerchio
	* @param r Lunghezza del raggio
	*
	*/
	public void setRaggio(double r){
		this.raggio=r;
	}
	
	/**
	*
	* Metodo definisce se un punto appartiene al cerchio
	*
	* @param p Punto da esaminare
	* @return true Punto appartenente al cerchio
	* @return false Punto non appartenente al cerchio
	*
	*/
	public boolean contienePunto(Point p){
		Segment s=new Segment(p,centro);
		double l=s.length();
		if(l <= raggio)
			return true;
		else
			return false;
	}
	
	/**
	*
	* Metodo che definisce il perimetro del cerchio
	* 
	* @return perimetro
	*
	*/
	public double perimetro(){
		return Math.PI*2*this.raggio;
	}
	
	
	/**
	*
	* Metodo che definisce l'area del cerchio
	* 
	* @return area
	*
	*/
	public double area(){
		return this.raggio*this.raggio*Math.PI;
	}
	
	/**
	*
	* Metodo che restituisce le caratteristiche del cerchio
	*
	* @return string Caratteristiche del cerchio
	*
	*/
	public String toString(){
		return "\n\t->Coordinate del centro: "+this.centro.toString()+"\n\t->Lunghezza del raggio: "+this.raggio+"\n\t->Perimetro: "+perimetro()+"\n\t->Area: "+area();
	}
}