/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shaders;

/**
*	Classe che determina un segmento dati due punti
*
*	@author Barbato Federico
*	@version 1.0.0
*
*/

import graphics.MasterGraphic;
import java.awt.Color;

public class Segment extends MasterGraphic implements java.io.Serializable{
	//Attributi
	private Point p1;		//Primo Punto
	private Point p2;		//Secondo Punto
	
	/**
	*	Costruttore per la classe Segment senza attributi grafici
	*
	*	@param p1 Primo punto
	*	@param p2 Secondo Punto
	*/
	public Segment(Point p1, Point p2){
		super(0,Color.black,true);
		this.p1=p1;
		this.p2=p2;
	}
	
	/**
	*	Costruttore per la classe Segment con attributi grafici
	*
	*	@param p1 Primo punto
	*	@param p2 Secondo Punto
	* @param l Spessore della linea
	* @param c Colore della linea
	* @param v Visibilità dell'oggetto
	*/
	public Segment(Point p1, Point p2, double l, Color c, boolean v){
		super(l,c,v);
		this.p1=p1;
		this.p2=p2;
	}
	
	/**
	*	Metodo che calcola la lunghezza del segmento
	*
	*	@return lunghezza Lunghezza del segmento
	*/
	public double length(){
		double lunghezza=p1.distance(p2);
		return lunghezza;
	}
	
	/**
	*	Metodo che restituisce il primo punto
	*
	*	@return p1 Primo punto
	*
	*/
	public Point getP1(){
		return this.p1;
	}
	
	/**
	*	Metodo che restituisce il secondo punto
	*
	*	@return p2 Secondo punto
	*
	*/
	public Point getP2(){
		return this.p2;
	}
	
	/**
	* 
	* Metodo che determina se un punto appartiene a un segmento
	* @param p Punto da confrontare
	* @return true/false Il punto se appartiene o no al segmento
	*
	*/
	public boolean puntoAppartiene(Point p){
		if(p instanceof Point){
			if(p1.distance(p)+p2.distance(p)==length())
				return true;
			else
				return false;	
		}else{
			return false;
		}
		
	}
	
	/**
	*	Metodo che restituisce una stringa di descrizione del segmento
	*	
	*
	*	@return Stringa
	*
	*/
	public String toString(){
		return "\n\t\t-->punto A"+ p1.toString()+"\n\t\t-->punto B"+ p2.toString() +"\n\t\t-->Lunghezza: "+length();
	}
	/**
	* Metodo che restituisce se due segmenti sono uguali
	*
	* @param s2 secondo segmento
	* @return true/false se due punti sono uguali
	*/
	public boolean equals(Object s2){
		Segment s;
		if(s2 instanceof Segment){
			s=(Segment)s2;
			if(this.p1.equals(s.getP1()) && this.p2.equals(s.getP2()))
				return true;
			else
				return false;
		}else{
			return false;
		}
		
	}
	
}
