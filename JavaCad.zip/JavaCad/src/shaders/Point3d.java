/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shaders;

/**
* Classe che determina le caratteristiche di un punto nelle tre dimensioni
*
* @author Barbato Federico
* @version 1.0.0
*
*/

import java.awt.Color;

public class Point3d extends Point implements java.io.Serializable{
	private double z;

	/**
	* Costruttore della classe che setta le caratteristiche del punto 3D con caratteristiche grafiche
	* 
	* @param x ascissa del punto
	* @param y ordinata del punto
	* @param z posizione asse z
	* @param l Spessore della linea
	* @param c Colore della linea
	* @param v Visibilità dell'oggetto
	*/
	public Point3d(double x, double y, double z, double l, Color c, boolean v){
		super(l,c,v,x,y);
		this.z=z;
	}
	
	/**
	* Costruttore della classe che setta le caratteristiche del punto 3D senza caratteristiche grafiche
	* 
	* @param x ascissa del punto
	* @param y ordinata del punto
	* @param z posizione asse z
	*/
	public Point3d(double x, double y, double z){
		super(x,y);
		this.z=z;
	}
	

	
	/**
	*
	* Metodo che setta la variabile z
	*
	* @param z Posizione asse z
	*/
	public void setZ(double z){
		this.z=z;
	}
	
	/**
	*
	* Metodo che ritorna la variabile z
	*
	* @return z
	*/
	public double getZ(){
		return this.z;
	}
	
	/**
	*
	* Metodo che calcola la distanza tra due punti 3d
	* @param p2 Punto 3d
	* @return d distanza tra i due punti 3d
	*
	*/
	public double distance(Point3d p2){
		double distanza=Math.sqrt((this.getX()-p2.getX())*(this.getX()-p2.getX())+(this.getY()-p2.getY())*(this.getY()-p2.getY())+(this.z-p2.getZ())*(this.z-p2.getZ()));
		return distanza;
	}
	
	/**
	* Metodo che restituisce se due punti hanno le stesse coordinate
	*
	* @param p2 secondo punto
	* @return true/false se due punti sono uguali
	*/
	public boolean equals(Object p2){
		Point3d p;
		if(p2 instanceof Point3d){
			p=(Point3d)p2;
			if(this.getX() == p.getX() && this.getY() == p.getY() && this.z == p.getZ())
				return true;
			else
				return false;
		}else{
			return false;
		}
		
	}
	
	/**
	*
	* Metodo che stampa a schermo le caratteristiche del punto 3D
	*
	* @return s Stringa di caratteristiche del punto
	*
	*/
	public String toString(){
		String s;
		s="("+getX()+";"+getY()+";"+this.z+")";
		return s;
	}
}
