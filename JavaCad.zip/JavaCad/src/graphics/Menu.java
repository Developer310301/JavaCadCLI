/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package graphics;

/**
 * Classe statica utilizzata per la visualizzazione dei menu
 * @author Barbato Federico
 */
public class Menu {
    public static String home(){
        
        String s="\t\tJAVACAD - HOME\n"
                + "\t01 - Inserisci oggetto\n"
                + "\t02 - Rimuovi oggetto\n"
                + "\t03 - Salva disegno\n"
                + "\t04 - Carica disegno\n"
                + "\t99 - Esci da JavaCad\n"
                + "\nEffettua la tua scelta: ";
        return s;
    }
    
    public static String insert(){
        
        String s="\t\tJAVACAD - INSERISCI OGGETTO\n"
                + "\t01 - Inserisci punto\n"
                + "\t02 - Inserisci punto 3D\n"
                + "\t03 - Inserisci segmento\n"
                + "\t04 - Inserisci segmento 3D\n"
                + "\t05 - Inserisci cerchio\n"
                + "\t06 - Inserisci sfera\n"
                + "\t99 - Ritorna sù\n"
                + "\nEffettua la tua scelta: ";
                
        
        return s;
    }
    
    public static String remove(){
        
        String s="\t\tJAVACAD - RIMUOVI OGGETTO\n"
                + "\t01 - Rimuovi punto\n"
                + "\t02 - Rimuovi punto 3D\n"
                + "\t03 - Rimuovi segmento\n"
                + "\t04 - Rimuovi segmento 3D\n"
                + "\t05 - Rimuovi cerchio\n"
                + "\t06 - Rimuovi sfera\n"
                + "\t99 - Ritorna sù\n"
                + "\nEffettua la tua scelta: ";
                
        return s;
    }
}
