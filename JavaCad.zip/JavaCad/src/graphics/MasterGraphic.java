/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package graphics;

/**
*
* Classe che caratterizza gli oggetti dal punto di vista grafico
*
* @version 1.0.0
* @author Barbato Federico
*
*
*/

import java.awt.Color;

public class MasterGraphic implements java.io.Serializable{
	
	public double spessoreLinea;
	public Color coloreLinea;
	public boolean visibilita;
	
	public MasterGraphic(double s, Color c, boolean v){
		this.spessoreLinea=s;
		this.coloreLinea=c;
		this.visibilita=v;
	}
	
}
